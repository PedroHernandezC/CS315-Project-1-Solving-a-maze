#include "maze.h"

#include <iostream>
#include <string>

int main(int argc, char* argv[]) {
    std::string fileName = "mazeInput.txt";

    if (argc == 2) {
        fileName = argv[1];
    }

    std::cout << "Passed file " << fileName << std::endl;

    Maze maze(fileName);
    maze.mazeRunner();

    return 0;
}