#include "maze.h"

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <tuple>

const int PATH = 0; // indicates an availible path
const int WALL = 1; // represents a wall
const int VISITED = 2; // visited spaces will be changed to a 2
const int SOLVED_PATH = 4;  // spots found to be on the correct will be replaced with a four

Maze::Maze() {
    std::cout << "call with file please" << std::endl;
}

// Pre: mapFile holds only 1s and 0s and each line must be the same size. File must be able to open
// Post: Maze object will have been initialized
Maze::Maze(const std::string& mapFile) {
    std::ifstream file(mapFile);

    if (!file.is_open()) {
        std::cout << "cant open map file" << std::endl;
        return;
    }

    std::string row;
    while (std::getline(file, row)) {
        std::vector<int> mapRow;
        for (char c : row) {
            if (c == '1' || c == '0') {
                mapRow.push_back(c - '0');
            }
        }
        if (!mapRow.empty()) {
            map.push_back(mapRow);
        }
    }

    file.close();
}

// Pre: Maze object was correctly initialized
// Post: Maze will have been printed with blanks being part of the solution, xs being explored sections
void Maze::printMaze() {
    for (const auto& row : map) {
        for (const auto& cell : row) {
            if (cell == VISITED) {
                std::cout << 'x';
            } else if (cell == SOLVED_PATH) {
                std::cout << ' ';
            }
            else {
                std::cout << cell;
            }
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// Pre: Maze object was correctly initialized
// Post: path will hold a tuple with the coordinate of the first opening
void Maze::findOpening() {
    // look at left and right for opening
    for (std::size_t i = 0; i < map.size(); ++i) {
        if (map[i][0] == PATH) {
            path.push(std::make_tuple(static_cast<int>(i), 0));
            map[i][0] = VISITED;
            return;
        }
        if (map[i][map[0].size() - 1] == PATH) {
            path.push(std::make_tuple(static_cast<int>(i), static_cast<int>(map[0].size() - 1)));
            map[i][map[0].size() - 1] = VISITED;
            return;
        }
    }

    // look at top and bottom of maze for opening
    for (std::size_t j = 0; j < map[0].size(); ++j) {
        if (map[0][j] == PATH) {
            path.push(std::make_tuple(0, static_cast<int>(j)));
            map[0][j] = VISITED;
            return;
        }
        if (map[map.size() - 1][j] == PATH) {
            path.push(std::make_tuple(static_cast<int>(map.size() - 1), static_cast<int>(j)));
            map[map.size() - 1][j] = VISITED;
            return;
        }
    }

}

// Pre: Maze object was correctly initialized
// Post: Outputs msg and solved maze depending on if a solution was found
void Maze::mazeRunner() {
    findOpening();
    if (path.empty()) {
        std::cout << "no opening in boundry was found." << std::endl;
        return;
    }

    auto [startRow, startCol] = path.top();

    if (solveMaze(startRow, startCol)) {
        std::cout << "Solution was found!" << std::endl;
        showFoundPath();
        printMaze();
    } else {
        std::cout << "No solution found." << std::endl;
    }
}

// Pre: Maze was initialized with expected maze formate
// Post: path will hold tuples that indicate the coords of the solution.
bool Maze::solveMaze(int row, int col) {
    // base case is when currently at another boundary but path is not empty
    if ((row == 0 || row == map.size() - 1 || col == 0 || col == map[0].size() - 1) && path.size() > 1) {
        return true;
    }

    // possible movements to look for neighbors
    // somewhat inspired from https://cplusplus.com/forum/general/189857/
    int movementOp[4][2] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};

    for (int i = 0; i < 4; ++i) {
        int tempRow = row + movementOp[i][0];
        int tempCol = col + movementOp[i][1];

        // is neighbor in bounds and is it available
        if (tempRow >= 0 && tempRow < map.size() && tempCol >= 0 && tempCol < map[0].size() && map[tempRow][tempCol] == PATH) {
            map[tempRow][tempCol] = VISITED;
            path.push(std::make_tuple(tempRow, tempCol));

            // re-call with new coord
            // if new call was true then also return true
            if (solveMaze(tempRow, tempCol)) {
                return true;
            }

            // this point is reached when no more available neighbors or exit was found
            // pops to backtrack
            path.pop();
        }
    }

    return false;
}

// Pre: Maze is initialized.
// Post: map will hold modified maze where the solution path is marked with th SOLVED_PATH symbol
void Maze::showFoundPath() {
    // copies path to preserve solution stack and then pops though the copy changing the corresponding cell symbols
    std::stack<std::tuple<int, int>> tempPath = path;
    while (!tempPath.empty()) {
        auto [row, col] = tempPath.top();
        map[row][col] = SOLVED_PATH;
        tempPath.pop();
    }
}