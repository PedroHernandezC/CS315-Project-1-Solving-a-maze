#ifndef MAZE_H
#define MAZE_H

#include <vector>
#include <string>
#include <stack>
#include <tuple>

class Maze {
public:
    Maze();

    // Pre: mapFile holds only 1s and 0s and each line must be the same size. File must be able to open
    // Post: Maze object will have been initialized
    Maze(const std::string& mapFile);

    // Pre: Maze object was correctly initialized
    // Post: Maze will have been printed with blanks being part of the solution, xs being explored sections
    void printMaze();

    // Pre: Maze object was correctly initialized
    // Post: Outputs msg and solved maze depending on if a solution was found
    void mazeRunner();

private:
    // will hold rows of the maze
    std::vector<std::vector<int>> map;

    // will hold solution to maze or will be empty of none is found
    std::stack<std::tuple<int, int>> path;

    // Pre: Maze object was correctly initialized
    // Post: path will hold a tuple with the coordinate of the first opening
    void findOpening();

    // Pre: Maze was initialized with expected maze formate
    // Post: path will hold tuples that indicate the coords of the solution.
    bool solveMaze(int row, int col);

    // Pre: Maze is initialized.
    // Post: map will hold modified maze where the solution path is marked with th SOLVED_PATH symbol
    void showFoundPath();
};

#endif
