# Project 1 -- Solving a maze
## Student Information: 
**Name**: Pedro Hernandez Carranza 

**Student ID**: 008806974

**Repository Link**: https://github.com/PedroHernandezC/CS315-Project-1-Solving-a-maze

## Reflection
This project has shown me a lot about how to structure code and how recursion works to solve a problem. By far the hardest part of this project was finding the base cases that would properly end the loop. there were many times where the program would never end or would end to early. I found that working on a small mazes and tracing the program path on a white board to be very helpful. The other difficult part of the project was deciding what should be a function and whether or not another class was needed to hold cell/tile data. Ultimately I did not create another class and instead modified the maze using various numbers with their own internal meaning.


- Collaboration & Sources:
  - The conversations I had and over header during Lab3 greatly helped my develop this project and helped with the general recursive process.
  - Tuples seamed like the right way to store coordinates, but I have not used them prior to this project, so I asked chatGPT for information on how to use them and how they could be used to store grid information. I also asked for examples of how files can be passed as command line arguments as this was also new to me.
  - Once I was done with my solution I asked chatGPT how my solution could be improved. The changes it recommended would have completely changed my solution and would have made the solving of the maze iterative instead of recursive so ignored those suggestions. What I found helpful is that it pointed out my use of 'magic numbers' that would be better stored as variables. These can now by found at the top of the maze.cpp file. While this isn't entirely necessary it definitely made my code more self explanatory.
  - This project was coded on Clion which would sometimes autofill statements which were sometimes usefully. Most of the times it would lead to new ideas/approaches that would not work out but its interesting to see what it thinks im trying to do.
  - Part of my solveMaze function was inspired by the following thread https://cplusplus.com/forum/general/189857/

- Implementation Details:
  - The program utilizes one class called Maze. It holds data in a multidimensional vector called map and holds coords of visited cells/tiles in a stack of tuples called path. 
  - The function findOpening looks at all the left/right top/bottom rows to the map to look for an opening.
  - The function printMaze iterates over the map vector and prints its content to the console.
  - The function mazeRunner calls findOpening and then calls the main function solveMaze. Depending on the output different prompts are displayed.
  - The function solveMaze takes the top coord in path and checks for viable neighbors and adds to the path and marks as visited and then recalls. If no spots are available then th top coord is popped and the function recalls. Once the stack is empty or coord is at an opening then the function stops recalling returns true or false depending on if it was found or not.
  - The function showFoundPath pops through the path marking all path tiles/cells with an empty space.

- Testing & Status:
  - Once the code was able to run I readily changed the maze file to see if the program would crash. when it did i would add more console text and used CLions debugger to slowly step through the program.
  - The maze crawler is recursive and returns true if a solution was found so testing status was easy to find out using if statements.